SET SERVEROUTPUT ON;
DECLARE
    num NUMBER := 153;  -- You can change this to test other numbers
    temp NUMBER;
    sum NUMBER := 0;
    remainder NUMBER;
    digits NUMBER;
BEGIN
    temp := num;
    digits := LENGTH(num);  -- Get the number of digits

    -- Loop to process each digit
    LOOP
        remainder := temp MOD 10;  -- Get the last digit
        
        -- Manually increment the sum to avoid using '+'
        sum := sum (remainder * remainder * remainder);  -- Calculate the sum of cubes manually
        temp := temp / 10;  -- Remove the last digit
        EXIT WHEN temp = 0;  -- Exit when all digits have been processed
    END LOOP;

    -- Compare the sum with the original number
    IF sum = num THEN
        DBMS_OUTPUT.PUT_LINE(num || ' is an Armstrong number');
    ELSE
        DBMS_OUTPUT.PUT_LINE(num || ' is not an Armstrong number');
    END IF;
END;

