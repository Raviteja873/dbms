 BEGIN
        DBMS_OUTPUT.PUT_LINE('Roses are red,');
        DBMS_OUTPUT.PUT_LINE('Violets are blue,');
        DBMS_OUTPUT.PUT_LINE('Sugar is sweet,');
        DBMS_OUTPUT.PUT_LINE('And so are you.');
    END;
    /