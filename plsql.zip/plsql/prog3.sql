SET SERVEROUTPUT ON;
DECLARE
  i NUMBER := 1;
BEGIN
  FOR line IN 1..4 LOOP
    FOR num IN 1..line LOOP
      DBMS_OUTPUT.PUT('* ');  
    END LOOP;
    DBMS_OUTPUT.PUT_LINE(''); 
  END LOOP;
END;
/
