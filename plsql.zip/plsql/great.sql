SET SERVEROUTPUT ON;  -- Enables output in SQL*Plus

DECLARE
    num1 NUMBER := 10;  -- First number
    num2 NUMBER := 20;  -- Second number
    num3 NUMBER := 15;  -- Third number
    greatest NUMBER;    -- Variable to store the greatest number
BEGIN
    -- Conditional checks to find the greatest number
    IF (num1 >= num2 AND num1 >= num3) THEN
        greatest := num1;
    ELSIF (num2 >= num1 AND num2 >= num3) THEN
        greatest := num2;
    ELSE
        greatest := num3;
    END IF;

    -- Output the result
    DBMS_OUTPUT.PUT_LINE('The greatest number is: ' || greatest);
END;
/
