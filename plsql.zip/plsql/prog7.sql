SET SERVEROUTPUT ON;
DECLARE
    a NUMBER := 0;
    b NUMBER := 1;
    c NUMBER;
    i NUMBER := 1;
BEGIN
    DBMS_OUTPUT.PUT_LINE('Fibonacci numbers from 1 to 30:');
    DBMS_OUTPUT.PUT_LINE(a); 
    DBMS_OUTPUT.PUT_LINE(b); 
    
    FOR i IN 3..30 LOOP
        c := a + b;
        DBMS_OUTPUT.PUT_LINE(c);
        a := b;
        b := c;
    END LOOP;
END;
/
