
SET SERVEROUTPUT ON;
 DECLARE
    start_num NUMBER := 1;
    BEGIN
      FOR line IN 1..4 LOOP
        FOR num IN 1..line LOOP
          DBMS_OUTPUT.PUT(line || ' ');
          start_num := start_num + 1;
        END LOOP;
        DBMS_OUTPUT.PUT_LINE('');
    END LOOP;
   END;
   /