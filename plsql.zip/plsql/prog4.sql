SET SERVEROUTPUT ON;
DECLARE
   input_string VARCHAR2(50);
   reversed_string VARCHAR2(50) := '';
   i NUMBER;
BEGIN
   input_string := 'madam'; -- Assign value inside BEGIN

   FOR i IN REVERSE 1..LENGTH(input_string) LOOP
      reversed_string := reversed_string || SUBSTR(input_string, i, 1);
   END LOOP;

   IF input_string = reversed_string THEN
      DBMS_OUTPUT.PUT_LINE(input_string || ' is a palindrome.');
   ELSE
      DBMS_OUTPUT.PUT_LINE(input_string || ' is not a palindrome.');
   END IF;
END;
/
